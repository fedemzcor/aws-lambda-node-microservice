const Joi = require('@hapi/joi');

module.exports.validateSchema = (config) => {
    const schema = Joi.object({
      username: Joi.string()
          .alphanum()
          .min(3)
          .max(30)
          .required(),

      password: Joi.string()
          .pattern(new RegExp('^[a-zA-Z0-9]{3,30}$')),
      email: Joi.string()
          .email({ minDomainSegments: 2, tlds: { allow: ['com', 'net'] } })
    });

    schema.validate(handler.event.body);

    return ({


      
     

      before: (handler, next) => {
         // haz algo antes que todo
      
        return next()
      },
      after: (handler, next) => {
    
        // haz aldo despues de que se ejecuto
        return next()
      },
      onError: (handler, next) => {
        // haz algo si ocurrio un error

        return next()
      }
    })
  }
  