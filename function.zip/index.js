const middy = require('middy')
const { validateSchema } = require("middlewares/validate-schema")
const handler = middy((event, context, callback) => {
  // do stuff
  return {
      "Message" : "Hola mundo"
  }
})

handler.use(validateSchema)
module.exports = { handler }